## PHP-MySQL

> PHP-MySQL crud operations using MySQLi

![display data](/screenshots/display_data.png)

![create data](/screenshots/create_data.png)

![update data](/screenshots/update_data.png)
